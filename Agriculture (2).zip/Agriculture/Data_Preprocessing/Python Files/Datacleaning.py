import pandas as pd
import numpy as np
import os
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

print("1. Loading all datasets...")

# Set your base path here to keep the code clean
base_path = r'C:\Users\avpc\Desktop\Agriculture\Data_Preprocessing\Data'

df_daily_price = pd.read_csv(os.path.join(base_path, '9ef84268-d588-465a-a308-a864a43d0070.csv'))
df_yield = pd.read_csv(os.path.join(base_path, 'crop_yield.csv'))
df_monthly_price = pd.read_csv(os.path.join(base_path, 'crop_price_dataset.csv'))
df_crop_profile = pd.read_csv(os.path.join(base_path, 'Crop-Profile_-State-wise-Area,-Production-&-Yield-of-All-Crops,-(2021-22-to-2025-26).csv'))
df_wpi = pd.read_csv(os.path.join(base_path, 'Wholesale-Price-Index-from-2012-to-2026.csv'))

print("2. Processing Old Yield Data...")
df_yield.rename(columns={'Crop_Year': 'Year'}, inplace=True)
yield_old = df_yield.groupby(['State', 'Crop', 'Year'])[['Area', 'Production', 'Annual_Rainfall', 'Fertilizer', 'Pesticide', 'Yield']].mean().reset_index()

print("3. Processing New Crop Profile (2021-2026) Data...")
# The Crop Profile has years as columns (e.g., "Area-2021-22"). We need to melt this.
metrics = ['Area', 'Production', 'Yield']
melted_prof = pd.DataFrame()

for metric in metrics:
    # Find all columns related to this metric
    metric_cols = [c for c in df_crop_profile.columns if c.startswith(metric)]
    base_cols = ['Crop', 'State', 'Season']
    
    # Melt the dataframe
    temp = df_crop_profile[base_cols + metric_cols].melt(id_vars=base_cols, var_name='Year_Str', value_name=metric)
    
    # Extract the starting year (e.g., 'Area-2021-22' -> 2021)
    temp['Year'] = temp['Year_Str'].str.extract(r'(\d{4})').astype(float)
    temp.drop(columns=['Year_Str'], inplace=True)
    
    # Convert metric values to numbers, coercing errors (like empty strings) to NaN
    temp[metric] = pd.to_numeric(temp[metric], errors='coerce')
    
    if melted_prof.empty:
        melted_prof = temp
    else:
        melted_prof = pd.merge(melted_prof, temp, on=['Crop', 'State', 'Season', 'Year'], how='outer')

# Aggregate the new profile data to yearly and drop NA years
yield_new = melted_prof.dropna(subset=['Year']).groupby(['State', 'Crop', 'Year'])[['Area', 'Production', 'Yield']].mean().reset_index()

# Combine old yield data and new yield data!
yield_master = pd.concat([yield_old, yield_new], ignore_index=True)
# Average out any overlapping years between the two datasets
yield_master = yield_master.groupby(['State', 'Crop', 'Year']).mean().reset_index()

print("4. Processing WPI (Wholesale Price Index) Data...")
# WPI has months as columns (e.g., "January-2013"). We will melt it and get yearly averages.
wpi_melt = df_wpi.melt(id_vars=['Crop'], var_name='Month_Year', value_name='WPI')
# Split "January-2013" into Month and Year
wpi_melt[['Month', 'Year']] = wpi_melt['Month_Year'].str.split('-', expand=True)
wpi_melt['Year'] = pd.to_numeric(wpi_melt['Year'], errors='coerce')
wpi_melt['WPI'] = pd.to_numeric(wpi_melt['WPI'], errors='coerce')

# Get yearly average WPI per crop
wpi_yearly = wpi_melt.groupby(['Crop', 'Year'])['WPI'].mean().reset_index()

print("5. Processing APMC & Monthly Price Data...")
# APMC Daily
df_daily_price.rename(columns={'Commodity': 'Crop', 'Min_x0020_Price': 'Min_Price', 'Max_x0020_Price': 'Max_Price', 'Modal_x0020_Price': 'Modal_Price'}, inplace=True)
df_daily_price['Arrival_Date'] = pd.to_datetime(df_daily_price['Arrival_Date'], format='%d/%m/%Y', errors='coerce')
df_daily_price['Year'] = df_daily_price['Arrival_Date'].dt.year
apmc_yearly = df_daily_price.groupby(['State', 'Crop', 'Year'])[['Min_Price', 'Max_Price', 'Modal_Price']].mean().reset_index()
apmc_yearly.rename(columns={'Min_Price': 'APMC_Yearly_Min', 'Max_Price': 'APMC_Yearly_Max', 'Modal_Price': 'APMC_Yearly_Modal'}, inplace=True)

# Monthly All-India
df_monthly_price.rename(columns={'commodity_name': 'Crop'}, inplace=True)
df_monthly_price['month'] = pd.to_datetime(df_monthly_price['month'], errors='coerce')
df_monthly_price['Year'] = df_monthly_price['month'].dt.year
if 'state_name' in df_monthly_price.columns:
    df_monthly_price.drop(columns=['state_name'], inplace=True)
monthly_yearly = df_monthly_price.groupby(['Crop', 'Year'])[['avg_modal_price', 'avg_min_price', 'avg_max_price', 'change']].mean().reset_index()

print("6. Standardizing Text for Final Merge...")
def clean_strings(df, cols):
    for col in cols:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().str.title()
    return df

string_cols = ['State', 'Crop']
yield_master = clean_strings(yield_master, string_cols)
apmc_yearly = clean_strings(apmc_yearly, string_cols)
monthly_yearly['Crop'] = monthly_yearly['Crop'].astype(str).str.strip().str.title()
wpi_yearly['Crop'] = wpi_yearly['Crop'].astype(str).str.strip().str.title()

print("7. Building the Final Master Dataset...")
# Merge Yield (Old + New) with local APMC prices
master_df = pd.merge(yield_master, apmc_yearly, on=['State', 'Crop', 'Year'], how='outer')

# Attach the All-India monthly prices
master_df = pd.merge(master_df, monthly_yearly, on=['Crop', 'Year'], how='left')

# Attach the WPI Macro Trends
master_df = pd.merge(master_df, wpi_yearly, on=['Crop', 'Year'], how='left')

# Sort data cleanly
master_df.sort_values(by=['State', 'Crop', 'Year'], inplace=True)

print("8. Splitting data by state and saving...")
output_dir = os.path.join(base_path, 'State_Datasets_Complete')
os.makedirs(output_dir, exist_ok=True)

# Filter out rows where State is NaN or 'Nan'
valid_states = master_df[~master_df['State'].isin(['Nan', 'None', ''])]['State'].dropna().unique()

for state in valid_states:
    state_df = master_df[master_df['State'] == state]
    safe_state_name = str(state).replace(' ', '_').replace('&', 'and')
    filename = f"{safe_state_name}_complete_data.csv"
    filepath = os.path.join(output_dir, filename)
    
    state_df.to_csv(filepath, index=False)
    print(f"  -> Saved {filename} ({len(state_df)} records)")

print(f"\nSUCCESS! All 5 files integrated. State files saved in: {output_dir}")