import pandas as pd
import numpy as np
import os

print("Loading datasets...")

# 1. Load the datasets (Using 'r' to prevent unicode errors)
df_daily_price = pd.read_csv(r'C:\Users\avpc\Desktop\Agriculture\9ef84268-d588-465a-a308-a864a43d0070.csv')
df_yield = pd.read_csv(r'C:\Users\avpc\Desktop\Agriculture\crop_yield.csv')
df_monthly_price = pd.read_csv(r'C:\Users\avpc\Desktop\Agriculture\crop_price_dataset.csv')

print("Standardizing columns and text...")

# 2. Standardize df_yield (This is our NEW Base Dataset because it has actual states)
df_yield.rename(columns={'Crop_Year': 'Year'}, inplace=True)
yield_yearly = df_yield.groupby(['State', 'Crop', 'Year'])[['Area', 'Production', 'Annual_Rainfall', 'Fertilizer', 'Pesticide', 'Yield']].mean().reset_index()

# 3. Standardize df_daily_price (Local APMC Data)
df_daily_price.rename(columns={
    'Commodity': 'Crop',
    'Min_x0020_Price': 'Min_Price',
    'Max_x0020_Price': 'Max_Price',
    'Modal_x0020_Price': 'Modal_Price'
}, inplace=True)
df_daily_price['Arrival_Date'] = pd.to_datetime(df_daily_price['Arrival_Date'], format='%d/%m/%Y')
df_daily_price['Year'] = df_daily_price['Arrival_Date'].dt.year

# Aggregate daily prices to yearly averages per State and Crop
apmc_yearly = df_daily_price.groupby(['State', 'Crop', 'Year'])[['Min_Price', 'Max_Price', 'Modal_Price']].mean().reset_index()
apmc_yearly.rename(columns={'Min_Price': 'APMC_Yearly_Min', 'Max_Price': 'APMC_Yearly_Max', 'Modal_Price': 'APMC_Yearly_Modal'}, inplace=True)

# 4. Standardize df_monthly_price (All-India Macro Trends)
df_monthly_price.rename(columns={'commodity_name': 'Crop'}, inplace=True)
df_monthly_price['month'] = pd.to_datetime(df_monthly_price['month'])
df_monthly_price['Year'] = df_monthly_price['month'].dt.year

# We drop 'state_name' here because it's always 'India' and will ruin our merge
if 'state_name' in df_monthly_price.columns:
    df_monthly_price.drop(columns=['state_name'], inplace=True)

# 5. Clean String Data (Ensuring merges work perfectly)
def clean_strings(df, cols):
    for col in cols:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().str.title()
    return df

string_cols = ['State', 'Crop']
yield_yearly = clean_strings(yield_yearly, string_cols)
apmc_yearly = clean_strings(apmc_yearly, string_cols)
df_monthly_price['Crop'] = df_monthly_price['Crop'].astype(str).str.strip().str.title()

print("Merging datasets...")

# 6. Merge the Data using an Outer Join so we don't lose ANY states
# First, merge Yield and local APMC prices on State, Crop, and Year
master_df = pd.merge(yield_yearly, apmc_yearly, on=['State', 'Crop', 'Year'], how='outer')

# Second, attach the All-India monthly prices based ONLY on Crop and Year
master_df = pd.merge(master_df, df_monthly_price, on=['Crop', 'Year'], how='left')

# Sort to make it readable
master_df.sort_values(by=['State', 'Crop', 'Year'], inplace=True)

print("Splitting data by state and saving to separate files...")

# 7. Split and Save by State
output_dir = r'C:\Users\avpc\Desktop\Agriculture\State_Datasets'
os.makedirs(output_dir, exist_ok=True)

# Get all unique states (dropping any blank/NaN state rows)
unique_states = master_df['State'].dropna().unique()

for state in unique_states:
    # Filter the master dataframe for just this state
    state_df = master_df[master_df['State'] == state]
    
    # Replace spaces with underscores for clean file names
    safe_state_name = str(state).replace(' ', '_').replace('&', 'and')
    filename = f"{safe_state_name}_agriculture_data.csv"
    filepath = os.path.join(output_dir, filename)
    
    # Save the file
    state_df.to_csv(filepath, index=False)
    print(f"  -> Saved {filename} ({len(state_df)} records)")

print(f"\nSuccess! All state files have been saved in: {output_dir}")