import pandas as pd
import os
import warnings

warnings.filterwarnings('ignore')

# 1. Define your folder paths (Update these!)
HISTORICAL_DIR = r'C:\Users\avpc\Desktop\Agriculture\Historical_Data'
UPAG_DIR = r'C:\Users\avpc\Desktop\Agriculture\UPAG_Data'
SOIL_DIR = r'C:\Users\avpc\Desktop\Agriculture\Soil_Health_Data'
OUTPUT_DIR = r'C:\Users\avpc\Desktop\Agriculture\Final_Merged_States'

os.makedirs(OUTPUT_DIR, exist_ok=True)

# 2. Function to load data and map it by the actual State name inside the file
def map_files_by_state(folder_path, data_category, state_dictionary):
    if not os.path.exists(folder_path):
        print(f"Warning: Folder not found - {folder_path}")
        return

    for filename in os.listdir(folder_path):
        if filename.endswith('.csv'):
            filepath = os.path.join(folder_path, filename)
            try:
                df = pd.read_csv(filepath)
                
                # Find the state column (handling slight naming variations)
                state_col = [col for col in df.columns if str(col).strip().lower() == 'state']
                
                if state_col:
                    # Clean the state name string
                    df[state_col[0]] = df[state_col[0]].astype(str).str.strip().str.title()
                    state_name = df[state_col[0]].iloc[0] # Grab the state name from the first row
                    
                    # Add to our dictionary
                    if state_name not in state_dictionary:
                        state_dictionary[state_name] = {}
                    
                    state_dictionary[state_name][data_category] = df
            except Exception as e:
                print(f"Error reading {filename}: {e}")

# 3. Build the Master Dictionary
print("Scanning folders and grouping files by State content...")
master_state_map = {}

map_files_by_state(HISTORICAL_DIR, 'historical', master_state_map)
map_files_by_state(UPAG_DIR, 'upag', master_state_map)
map_files_by_state(SOIL_DIR, 'soil', master_state_map)

print(f"Detected {len(master_state_map)} unique states. Beginning merge process...\n")

# 4. Process and Merge each State
for state, datasets in master_state_map.items():
    print(f"Processing: {state}")
    
    hist_df = datasets.get('historical', pd.DataFrame())
    upag_df = datasets.get('upag', pd.DataFrame())
    soil_df = datasets.get('soil', pd.DataFrame())
    
    combined_df = pd.DataFrame()
    
    # --- Step A: Combine Historical & UPAG ---
    if not hist_df.empty and not upag_df.empty:
        # Standardize Crop column
        hist_df['Crop'] = hist_df['Crop'].astype(str).str.strip().str.title()
        upag_df['Crop'] = upag_df['Crop'].astype(str).str.strip().str.title()
        
        # Calculate environmental averages from historical to inject into UPAG
        env_cols = [c for c in ['Annual_Rainfall', 'Fertilizer', 'Pesticide'] if c in hist_df.columns]
        if env_cols:
            env_avg = hist_df.groupby('Crop')[env_cols].mean().reset_index()
            upag_smart = pd.merge(upag_df, env_avg, on='Crop', how='left')
            
            # Fill remaining NaNs with state-wide averages
            for col in env_cols:
                state_avg = hist_df[col].mean()
                upag_smart[col] = upag_smart[col].fillna(state_avg)
                
            combined_df = pd.concat([hist_df, upag_smart], ignore_index=True)
        else:
            combined_df = pd.concat([hist_df, upag_df], ignore_index=True)
            
    elif not hist_df.empty:
        combined_df = hist_df.copy()
    elif not upag_df.empty:
        combined_df = upag_df.copy()
    
    # --- Step B: Merge Soil Data ---
    if not combined_df.empty and not soil_df.empty:
        # Check if we can merge on District, otherwise merge on State
        district_col_main = [c for c in combined_df.columns if 'district' in c.lower()]
        district_col_soil = [c for c in soil_df.columns if 'district' in c.lower()]
        
        if district_col_main and district_col_soil:
            # Clean district text for matching
            combined_df[district_col_main[0]] = combined_df[district_col_main[0]].astype(str).str.strip().str.title()
            soil_df[district_col_soil[0]] = soil_df[district_col_soil[0]].astype(str).str.strip().str.title()
            
            # Left join the soil data onto the main data based on District
            combined_df = pd.merge(combined_df, soil_df, left_on=district_col_main[0], right_on=district_col_soil[0], how='left')
        else:
            # If no district breakdown, merge on State
            combined_df = pd.merge(combined_df, soil_df, on='State', how='left')

    # --- Step C: Save the Final File ---
    if not combined_df.empty:
        # Sort chronologically if Year exists
        if 'Year' in combined_df.columns and 'Crop' in combined_df.columns:
            combined_df = combined_df.sort_values(by=['Crop', 'Year'])
            
        safe_filename = state.replace(' ', '_').replace('&', 'and') + "_Master.csv"
        output_path = os.path.join(OUTPUT_DIR, safe_filename)
        combined_df.to_csv(output_path, index=False)
        
        # Log what was included
        components = []
        if not hist_df.empty: components.append("Historical")
        if not upag_df.empty: components.append("UPAG")
        if not soil_df.empty: components.append("Soil Health")
        
        print(f"  -> Saved {safe_filename} (Merged: {', '.join(components)})")
    else:
        print(f"  -> Skipped {state} (No valid data to merge)")

print(f"\nAll operations complete! Final state files are located in: {OUTPUT_DIR}")