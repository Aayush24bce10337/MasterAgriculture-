import pandas as pd
import os

# 1. Load your downloaded UPAG data
# Change 'upag_data.csv' to the actual name of the file you downloaded
upag_file = r'C:\Users\avpc\Desktop\Agriculture\upag_data.csv' 

print(f"Loading UPAG data from: {upag_file}")
df_upag = pd.read_csv(upag_file)

# 2. Clean the text columns to ensure perfect matching
# This fixes issues where "West Bengal " and "West Bengal" are treated differently
df_upag['State'] = df_upag['State'].astype(str).str.strip().str.title()
df_upag['Crop'] = df_upag['Crop'].astype(str).str.strip().str.title()

# 3. Create a dedicated folder for these new files
output_dir = r'C:\Users\avpc\Desktop\Agriculture\UPAG_State_Data'
os.makedirs(output_dir, exist_ok=True)

# 4. Separate and Save!
unique_states = df_upag['State'].dropna().unique()

print("\nSplitting data by state...")
for state in unique_states:
    # Filter data for this specific state
    state_data = df_upag[df_upag['State'] == state]
    
    # Create a safe, clean filename (e.g., 'Andhra_Pradesh_UPAG.csv')
    safe_state_name = state.replace(' ', '_').replace('&', 'and')
    filename = f"{safe_state_name}_UPAG.csv"
    filepath = os.path.join(output_dir, filename)
    
    # Save to CSV
    state_data.to_csv(filepath, index=False)
    print(f"  ✅ Saved {len(state_data)} records -> {filename}")

print(f"\n🎉 Success! All UPAG state files are saved in: {output_dir}")