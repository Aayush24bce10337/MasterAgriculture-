import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import requests
import datetime
import warnings

warnings.filterwarnings('ignore')

st.set_page_config(page_title="Agri-Intelligence Master", page_icon="🌱", layout="wide")

# ==========================================
# NASA API & SMART DICTIONARY
# ==========================================
def get_nasa_annual_rainfall(lat, lon):
    year = datetime.datetime.now().year - 1 
    url = f"https://power.larc.nasa.gov/api/temporal/daily/point?parameters=PRECTOTCORR&community=AG&longitude={lon}&latitude={lat}&start={year}0101&end={year}1231&format=JSON"
    try:
        response = requests.get(url, timeout=10)
        data = response.json()
        daily_rainfall = data['properties']['parameter']['PRECTOTCORR']
        valid_rainfall = [val for val in daily_rainfall.values() if val != -999.0]
        return sum(valid_rainfall)
    except Exception:
        return None

def get_crop_prescription(crop_name):
    crop = str(crop_name).lower()
    
    if 'rice' in crop or 'paddy' in crop:
        return "Requires high Nitrogen. Best suited for Urea and Zinc Sulphate in flooded conditions."
    elif 'wheat' in crop:
        return "Requires balanced NPK. Best suited for DAP (Diammonium Phosphate) at sowing, followed by top-dressed Urea."
    elif 'sugarcane' in crop:
        return "Heavy feeder. Requires massive Nitrogen (Urea) split across multiple doses, plus Potash (MOP) for cane girth."
    elif 'cotton' in crop:
        return "Requires deep Phosphorus (DAP) and Potassium (MOP) for boll development. Monitor for magnesium deficiency."
    elif 'maize' in crop or 'corn' in crop:
        return "Highly responsive to Nitrogen and Zinc. Use Urea and Zinc Sulphate. Requires good drainage."
    elif 'potato' in crop:
        return "Needs high Potassium for tuber sizing. Use MOP (Muriate of Potash) alongside DAP."
    elif 'onion' in crop or 'garlic' in crop:
        return "Requires high Sulfur for pungency and bulb development. Single Super Phosphate (SSP) is highly recommended."
    elif any(x in crop for x in ['gram', 'dal', 'pea', 'bean', 'lentil', 'moong', 'urad', 'arhar', 'tur', 'chana', 'masur', 'soy']):
        return "Legume (fixes its own nitrogen). Do NOT over-apply Urea. Focus strictly on Phosphorus (SSP/DAP) and Sulfur."
    elif any(x in crop for x in ['mustard', 'rapeseed', 'groundnut', 'castor', 'sesamum', 'linseed', 'sunflower', 'safflower', 'niger', 'oilseed']):
        return "Oilseed. Highly dependent on Sulfur for oil extraction percentage. Gypsum or SSP application is critical."
    elif any(x in crop for x in ['gourd', 'cucumber', 'pumpkin', 'melon', 'squash', 'ashgourd', 'tinda']):
        return "Cucurbit vine. Requires balanced NPK with a focus on Potassium during flowering/fruiting."
    elif any(x in crop for x in ['mango', 'apple', 'banana', 'guava', 'papaya', 'grape', 'citrus', 'lemon', 'orange', 'pomegranate', 'kinnow', 'fig', 'chikoo']):
        return "Fruit crop. Requires annual basal application of FYM, with NPK and micronutrients during fruit setting."
    elif any(x in crop for x in ['bajra', 'jowar', 'ragi', 'millet', 'sorghum', 'kodo', 'kutki']):
        return "Hardy coarse cereal. Low fertilizer requirement. A light basal dose of Urea and DAP is usually sufficient."
    elif any(x in crop for x in ['cabbage', 'cauliflower', 'spinach', 'leafy', 'amaranthus', 'methi']):
        return "Leafy vegetable. Nitrogen-heavy requirement for rapid vegetative growth. Split doses of Urea work best."
    elif any(x in crop for x in ['coriander', 'turmeric', 'ginger', 'pepper', 'cardamom', 'tamarind', 'soanf']):
        return "Spice crop. Requires rich organic matter. Focus on compost, moderate Phosphorus, and Potassium."
    else:
        return "Requires a standard balanced NPK mix based on local soil health card recommendations."

if 'rainfall_val' not in st.session_state:
    st.session_state.rainfall_val = 1800.0

# --- Header ---
st.title("🌱 Master Agriculture Intelligence Dashboard")
st.markdown("Predict localized yields and prescribe precise agronomic treatments using AI.")
st.divider()

# ==========================================
# DATA LOADING & STATE SELECTION
# ==========================================
st.sidebar.header("📁 Upload State Master Files")
st.sidebar.markdown("Upload your merged State CSV files here.")

uploaded_files = st.sidebar.file_uploader("Upload State CSVs", type=['csv'], accept_multiple_files=True)

@st.cache_data
def process_uploaded_files(files):
    state_dict = {}
    for file in files:
        df = pd.read_csv(file)
        if 'State' in df.columns:
            state_name = str(df['State'].iloc[0]).strip().title()
        else:
            state_name = file.name.replace("_Master.csv", "").replace("_", " ").title()
        state_dict[state_name] = df
    return state_dict

# ==========================================
# AI TRAINING ENGINE
# ==========================================
@st.cache_resource
def train_model(df):
    required_cols = ['Yield', 'Annual_Rainfall', 'Crop', 'Area']
    if not all(col in df.columns for col in required_cols):
        return None, None
        
    model_df = df.dropna(subset=required_cols)
    if model_df.empty:
        return None, None
        
    model_df['Fertilizer'] = model_df['Fertilizer'].fillna(0)
    model_df['Pesticide'] = model_df['Pesticide'].fillna(0)
    
    model_df['Fert_per_Ha'] = model_df['Fertilizer'] / model_df['Area']
    model_df['Pest_per_Ha'] = model_df['Pesticide'] / model_df['Area']
    
    model_df.replace([np.inf, -np.inf], 0, inplace=True)
    model_df.fillna(0, inplace=True)
    
    crop_encoder = LabelEncoder()
    model_df['Crop_Encoded'] = crop_encoder.fit_transform(model_df['Crop'])
    
    X = model_df[['Crop_Encoded', 'Annual_Rainfall', 'Fert_per_Ha', 'Pest_per_Ha']]
    y = model_df['Yield']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    rf_model = RandomForestRegressor(n_estimators=100, max_depth=7, min_samples_split=10, random_state=42)
    rf_model.fit(X_train, y_train)
    
    return rf_model, crop_encoder

# ==========================================
# MAIN APP LOGIC
# ==========================================
if not uploaded_files:
    st.info("👈 Please drag and drop your state CSV files into the sidebar to begin.")
else:
    with st.spinner("Processing State Data..."):
        state_data_map = process_uploaded_files(uploaded_files)
        
        state_list = sorted(list(state_data_map.keys()))
        selected_state = st.sidebar.selectbox("🗺️ Select a State to Analyze:", state_list)
        
        df = state_data_map[selected_state]
        st.sidebar.success(f"✅ Active: {selected_state} ({len(df)} records)")
        
        soil_cols = [c for c in df.columns if 'nitrogen' in c.lower() or 'phosphorus' in c.lower() or 'district' in c.lower()]
        if soil_cols:
            st.success(f"🌍 Soil Health Data is available for {selected_state}!")
        
        rf_model, crop_encoder = train_model(df)
        
        # Split the workflow into two clean columns
        col1, col2 = st.columns(2)

        if rf_model is None:
            st.error(f"⚠️ **Insufficient Agronomy Data.**\n\n{selected_state} does not have enough historical rainfall or area data to safely train the AI model.")
        else:
            # ------------------------------------------
            # LEFT COLUMN: ENVIRONMENT & CROP SELECTION
            # ------------------------------------------
            with col1:
                st.header("🌦️ 1. Environment Setup")
                with st.container(border=True):
                    st.markdown("**🛰️ NASA Live Weather Sync**")
                    cA, cB = st.columns(2)
                    
                    lat = cA.number_input("Latitude", value=26.4499, format="%.4f")
                    lon = cB.number_input("Longitude", value=80.3319, format="%.4f")
                    
                    if st.button("Sync NASA Data", use_container_width=True):
                        rain = get_nasa_annual_rainfall(lat, lon)
                        if rain:
                            st.session_state.rainfall_val = float(rain)
                            st.success(f"Synced! {rain:.2f} mm of rain recorded last year.")
                    
                    rainfall = st.slider("Expected Annual Rainfall (mm)", 500.0, 4000.0, st.session_state.rainfall_val)
                    farm_size = st.number_input("Farm Size (Hectares)", min_value=0.1, value=1.0, step=0.5)
                    
                    # Biological Survival Filter
                    crop_tolerances = df.groupby('Crop')['Annual_Rainfall'].agg(['min', 'max']).reset_index()
                    surviving_crops = []
                    
                    for crop in crop_encoder.classes_:
                        bounds = crop_tolerances[crop_tolerances['Crop'] == crop]
                        if not bounds.empty:
                            min_rain = bounds['min'].values[0]
                            max_rain = bounds['max'].values[0]
                            if rainfall >= (min_rain * 0.70) and rainfall <= (max_rain * 1.30):
                                surviving_crops.append(crop)
                
                st.header("🌱 2. Crop Selection")
                with st.container(border=True):
                    if len(surviving_crops) == 0:
                        st.error("⚠️ **Extreme Weather!** No crops can survive this rainfall.")
                        selected_crop = None
                    else:
                        selected_crop = st.selectbox("Select a sustainable crop:", sorted(surviving_crops))
                        prescription = get_crop_prescription(selected_crop)
                        st.info(f"**💡 Expert Prescription:**\n{prescription}")

            # ------------------------------------------
            # RIGHT COLUMN: RESOURCE ALLOCATION & YIELD
            # ------------------------------------------
            with col2:
                if selected_crop:
                    st.header("🚜 3. Resource Allocation")
                    with st.container(border=True):
                        st.markdown(f"**Allocate inputs for your {farm_size} Ha farm:**")
                        fertilizer = st.number_input(f"Total Fertilizer for {selected_crop} (kg)", min_value=0, value=150, step=10)
                        pesticide = st.number_input(f"Total Pesticide for {selected_crop} (kg)", min_value=0, value=5, step=1)
                        
                        user_fert_per_ha = fertilizer / farm_size
                        user_pest_per_ha = pesticide / farm_size
                        
                        # AI Yield Math
                        valid_area_df = df[df['Area'] > 0]
                        valid_area_df['Hist_Fert_Ha'] = valid_area_df['Fertilizer'] / valid_area_df['Area']
                        baseline_fert = valid_area_df.groupby('Crop')['Hist_Fert_Ha'].mean().to_dict()
                        crop_max_yields = df.groupby('Crop')['Yield'].max().to_dict()
                        
                        enc = crop_encoder.transform([selected_crop])[0]
                        sim = pd.DataFrame({
                            'Crop_Encoded': [enc], 
                            'Annual_Rainfall': [rainfall], 
                            'Fert_per_Ha': [user_fert_per_ha], 
                            'Pest_per_Ha': [user_pest_per_ha]
                        })
                        
                        base_yield = rf_model.predict(sim)[0]
                        
                        # Diminishing Returns Curve
                        crop_avg_fert = baseline_fert.get(selected_crop, 1.0) 
                        if crop_avg_fert <= 0: crop_avg_fert = 1.0 
                        
                        fert_ratio = user_fert_per_ha / crop_avg_fert
                        if fert_ratio < 1.0:
                            multiplier = 0.50 + (0.50 * fert_ratio) 
                        else:
                            multiplier = 1.0 + (0.15 * (1 - (1 / fert_ratio))) 
                            
                        final_yield = base_yield * multiplier
                        max_possible = crop_max_yields.get(selected_crop, final_yield)
                        efficiency = (final_yield / max_possible) * 100 if max_possible > 0 else 0
                        efficiency = min(efficiency, 99.9)
                        
                        st.success(f"📊 Agronomic Projection")
                        c1, c2 = st.columns(2)
                        c1.metric(label="Estimated Yield", value=f"{final_yield:.2f} T/Ha")
                        c2.metric(label="Plant Suitability", value=f"{efficiency:.1f}%")
                        
                        if efficiency < 50:
                            st.warning("Your projected yield is far below this crop's historical maximum. Consider adjusting your fertilizer input to meet the expert prescription.")